import './App.css';
import Elegante from './image/Elegante.png'
import ShopeNewArrival from './image/shopnewarrivals.png'
import Nail from './image/nail.png'
import paint from './image/paint.png'
import sampoo from './image/sampoo.png'
import varniser from './image/varniser.png'
import mackupset from './image/mackupset.png'
import haircareset from './image/haircare.png'
import facepaint from './image/faceliner.png'
import cocobutter from './image/Cocobutter.png'
import hairfinity from './image/Hairfinity.png'
import mackup from './image/mackup.png'
import FRAGRANCE from './image/Fragrance.png'
import skinPerson from './image/Skin & Personal Care.png'
import fashionAppare from './image/Fashion & Apparel.png'
import ToolAass from './image/Tools & Accessories.png'
import Ipsum from './image/Ipsum.png'
import Lorem from './image/lorem.png'
import Dolor from './image/dolor.png'
import SampooOil from './image/Sam-poo.png'
import SkinSuccess from './image/SkinSuccess.png'
import CoconutOilFormula from './image/CoconutOilFormula.png'
import NailPiant from './image/nailPaint.png'
import IconFragnance from './image/IconFragnance.png'
import VisitSpa from './image/VisitSpa.png'
import FarmHouse from './image/FarmHouse.png'
import Saloon from './image/Saloon.png'
import LaGIrl from './image/LaGIrl.png'
import CopyBilley from './image/CopyBilley.png'
import productGlrl from './image/productGlrl.png'
import Twitter from './image/twitter.svg'
import Facebook from './image/facebook.svg'
import Insta from './image/insta.svg'
import Paypl from './image/Paypl.png'

function App() {
  return (
    <div className="App">
      <div className='nav'>
        <div className='nav-inner'>
          <nav>
            <ul>
              <li><a href="#" >The View @ Elegante</a></li>
              <li><a href="#">Eleganté Mall</a></li>
              <li><a href="#">Salon</a></li>
              <li><a href="#">Conference & Events</a></li>
              <li><a href="#">Training</a></li>
              <li><a href="#">Spa</a></li>
              <li><a href="#">Studio</a></li>
              <li><a href="#">Restaurant</a></li>
              <li><a href="#">Arcade</a></li>
            </ul>
          </nav>
        </div>
      </div>
      {/* <!---end of Nav---> */}
      <div className='header'>
        <div className='header-inner'>
          <header>
            <ul style={{ display: 'flex' }}>
              <li> <img src={Elegante} className='eleGante'></img></li>

              <li className='searchBox'>
                <div className="form-group has-search">
                  <span class="fa fa-search form-control-feedback"></span>
                  <input type="text" class="form-control" />
                </div>
              </li>

              <li className='myAco'><i className="bi bi-person"></i><a href='#' className='myAccInfo'>MY ACCOUNT</a></li>
              <li><a href='#' className='myBasket'>BASKET</a></li>
            </ul>
            <div className='makeupHeader'>
              <ul className='headerTools'>
                <li><a href="#" >HAIR </a></li>
                <li><a href="#" >HAIR CARE</a></li>
                <li><a href="#" >SKIN & PERSONAL CARE</a></li>
                <li><a href="#" >MAKEUP</a></li>
                <li><a href="#" >FRAGRANCE</a></li>
                <li><a href="#" >TOOLS & ACCESSORIES</a></li>
                <li><a href="#" >FASHION & APPAREL</a></li>
              </ul>
            </div>


          </header>

        </div>
      </div>
      <div className='getOff'>
        <ul >
          <li><a href="#" >GET 10% OFF YOUR FIRST ORDER</a></li>
          <li><a href="#" >GET 10% OFF YOUR FIRST ORDER</a></li>
          <li><a href="#" >GET 10% OFF YOUR FIRST ORDER</a></li>
          <li><a href="#" >GET 10% OFF YOUR FIRST ORDER</a></li>
        </ul>

      </div>
      {/* <!---end of Header ---> */}

      <div class="row">
        <div class="column" >

          <div className='shopText'><p>Shop New Arrivals</p><button className="buttonTxt">SHOP NOW</button></div>

        </div>
        <div class="column" >
          <img src={ShopeNewArrival} className='shopArrivalImg'></img>

        </div>
      </div>
      {/* Tranding Now Start */}
      <div className="rowTrands">
        <h3 className='trandingTxt'>TRENDING NOW</h3>
        <div className="columnTrands" >
          <img src={facepaint} className='imgTrands'></img>
          <h4>Trend setting makeup</h4>
          <p>Lorem ipsum dolor sit amet, consetetur</p>

        </div>
        <div class="columnTrands" >
          <img src={paint} className='imgTrands'></img>
          <h4>New makeup brushes</h4>
          <p>Lorem ipsum dolor sit amet, consetetur</p>

        </div>
        <div class="columnTrands" >
          <img src={Nail} className='imgTrands'></img>
          <h4>This seasons hottest nail polish</h4>
          <p>Lorem ipsum dolor sit amet, consetetur</p>
        </div>
      </div>
      {/* Discover start here */}
      <div className="rowDiscover">
        <h3 className='discoverTxth'>DISCOVER</h3>
        <div className="columnDiscover" >
          <img src={sampoo} className='imgTrands'></img>
          <p className='discoverTxt'>HAIR CARE</p>
          <p>Maui Shampoo</p>
          <p>₦ 29.99</p>
          <span class="fa fa-star checked"></span>
          <span class="fa fa-star checked"></span>
          <span class="fa fa-star checked"></span>
          <span class="fa fa-star checked"></span>
          <span class="fa fa-star-half-full checked"></span>

        </div>
        <div class="columnDiscover" >
          <img src={haircareset} className='imgTrands'></img>
          <p className='discoverTxt'>SKIN & PERSONAL CARE</p>
          <p>Hair Care Set</p>
          <p>₦ 34.99</p>
          <span class="fa fa-star checked"></span>
          <span class="fa fa-star checked"></span>
          <span class="fa fa-star checked"></span>
          <span class="fa fa-star"></span>
          <span class="fa fa-star"></span>

        </div>
        <div class="columnDiscover" >
          <img src={varniser} className='imgTrands'></img>
          <p className='discoverTxt'>SKIN & PERSONAL CARE</p>
          <p>YSL Nail Varnishes</p>
          <p>₦ 89.99</p>
          <span class="fa fa-star checked"></span>
          <span class="fa fa-star checked"></span>
          <span class="fa fa-star checked"></span>
          <span class="fa fa-star checked"></span>
          <span class="fa fa-star-half-full checked"></span>
        </div>
        <div class="columnDiscover" >
          <img src={mackupset} className='imgTrands'></img>
          <p className='discoverTxt'>MAKEUP</p>
          <p>Nude Makeup Set</p>
          <p>₦ 23.99</p>
          <span class="fa fa-star checked"></span>
          <span class="fa fa-star checked"></span>
          <span class="fa fa-star checked"></span>
          <span class="fa fa-star checked"></span>
          <span class="fa fa-star-half-full checked"></span>
        </div>
      </div>
      {/* Lorem ipsum dolor sit amet, consetetur */}
      <div className="rowLorem">

        <div className="columnLorem" >
          <img src={cocobutter} className='imgLorem'></img>
          <h4>Lorem ipsum dolor sit amet, consetetur</h4>
          <p>Lorem ipsum dolor sit amet, consetetur</p>
          <button className="buttonTxtLorem">SHOP NOW</button>
        </div>
        <div class="columnLorem" >
          <img src={hairfinity} className='imgLorem'></img>
          <h4>Lorem ipsum dolor sit amet, consetetur</h4>
          <p>Lorem ipsum dolor sit amet, consetetur</p>
          <button className="buttonTxtLorem">SHOP NOW</button>
        </div>

      </div>
      {/* SHOP BY CATEGORY */}
      <div style={{ marginLeft: "10px" }}>
        <h4 className='categoryTxt'>SHOP BY CATEGORY</h4>

      </div>
      <div className="rowCategory">

        <div class="columnCategory" >
          <img src={mackup} className='imgCategory'></img>
          <h4 className='cattext'>Makeup</h4>

        </div>
        <div class="columnCategory" >
          <img src={FRAGRANCE} className='imgCategory'></img>
          <h4 className='cattext'>Fragrance</h4>

        </div>
        <div class="columnCategory" >
          <img src={skinPerson} className='imgCategory'></img>
          <h4 className='cattext'>Skin & Personal Care</h4>

        </div>
        <div class="columnCategory" >
          <img src={fashionAppare} className='imgCategory'></img>
          <h4 className='cattext'>Fashion & Apparel</h4>

        </div>
        <div class="columnCategory" >
          <img src={ToolAass} className='imgCategory'></img>
          <h4 className='cattext'>Tools & Accessories</h4>

        </div>

      </div>
      {/* Lorem ipsum dolor sit amet, consetetur   */}
      <div className="rowDolor">

        <div className="dolorLorem" >
          <img src={Lorem} className='imgDolor'></img>
          <h4>Lorem ipsum dolor sit amet, consetetur</h4>
          <p>Lorem ipsum dolor sit amet, consetetur</p>
          <button className="buttonTxtLorem">SHOP NOW</button>

        </div>
        <div class="dolorLorem" >
          <img src={Ipsum} className='imgDolor'></img>
          <h4>Lorem ipsum dolor sit amet, consetetur</h4>
          <p>Lorem ipsum dolor sit amet, consetetur</p>
          <button className="buttonTxtLorem">SHOP NOW</button>

        </div>
        <div class="dolorLorem" >
          <img src={Dolor} className='imgDolor'></img>
          <h4>Lorem ipsum dolor sit amet, consetetur</h4>
          <p>Lorem ipsum dolor sit amet, consetetur</p>
          <button className="buttonTxtLorem">SHOP NOW</button>

        </div>

      </div>
      <div className="rowOffers">
        <h3 className='offersTxt'>OFFERS OF THE WEEK</h3>
        <div className="columnOffers" >
          <img src={SampooOil} className='imgOffers'></img>
          <p className='offersTxt'>HAIR CARE</p>
          <p>Maui Shampoo</p>
          <p>₦ 29.99</p>
          <span class="fa fa-star checked"></span>
          <span class="fa fa-star checked"></span>
          <span class="fa fa-star checked"></span>
          <span class="fa fa-star checked"></span>
          <span class="fa fa-star-half-full checked"></span>

        </div>
        <div class="columnOffers" >
          <img src={SkinSuccess} className='imgOffers'></img>
          <p className='offersTxt'>SKIN & PERSONAL CARE</p>
          <p>Hair Care Set</p>
          <p>₦ 34.99</p>
          <span class="fa fa-star checked"></span>
          <span class="fa fa-star checked"></span>
          <span class="fa fa-star checked"></span>
          <span class="fa fa-star"></span>
          <span class="fa fa-star"></span>

        </div>
        <div class="columnOffers" >
          <img src={CoconutOilFormula} className='imgOffers'></img>
          <p className='offersTxt'>SKIN & PERSONAL CARE</p>
          <p>YSL Nail Varnishes</p>
          <p>₦ 89.99</p>
          <span class="fa fa-star checked"></span>
          <span class="fa fa-star checked"></span>
          <span class="fa fa-star checked"></span>
          <span class="fa fa-star checked"></span>
          <span class="fa fa-star-half-full checked"></span>
        </div>
        <div class="columnOffers" >
          <img src={NailPiant} className='imgOffers'></img>
          <p className='offersTxt'>MAKEUP</p>
          <p>Nude Makeup Set</p>
          <p>₦ 23.99</p>
          <span class="fa fa-star checked"></span>
          <span class="fa fa-star checked"></span>
          <span class="fa fa-star checked"></span>
          <span class="fa fa-star checked"></span>
          <span class="fa fa-star-half-full checked"></span>
        </div>
      </div>

      <div class="rowElitr">
        <div class="columnElitr" >

          <div >
            <h2 style={{ marginTop: "126px" }}>Lorem ipsum dolor sit amet, consetetur</h2>
            <p>Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua.
              At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren.</p>
            <button className="buttonTxtElitr">FIND OUT MORE</button></div>

        </div>
        <div class="columnElitr" >
          <img src={IconFragnance} className='shopElitrImg'></img>

        </div>
      </div>
      <div className="rowSpa">

        <div className="spaColumn" >
          <img src={VisitSpa} className='imgSpa'></img>
          <h4>Visit Our Spa</h4>
          <p>Lorem ipsum dolor sit amet, consetetur</p>
          <button className="buttonTxtLorem">SHOP NOW</button>

        </div>
        <div class="spaColumn" >
          <img src={FarmHouse} className='imgSpa'></img>
          <h4>Visit Our Restaurant</h4>
          <p>Lorem ipsum dolor sit amet, consetetur</p>
          <button className="buttonTxtLorem">SHOP NOW</button>

        </div>
        <div class="spaColumn" >
          <img src={Saloon} className='imgSpa'></img>
          <h4>Visit Our Salon</h4>
          <p>Lorem ipsum dolor sit amet, consetetur</p>
          <button className="buttonTxtLorem">SHOP NOW</button>

        </div>

      </div>
      <div className="rowAmet">

        <div className="ametColumn" >

          <h4 style={{ marginTop: "165px" }}>Visit Our Spa</h4>
          <p>Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut.</p>
          <button className="buttonTxtAmet">VIEW ALL</button>

        </div>
        <div class="ametColumn" >
          <img src={LaGIrl} className='imgAmet'></img>
          <p>21.02.2022</p>
          <h4>Title goes here can go on two lines</h4>


        </div>
        <div class="ametColumn" >
          <img src={CopyBilley} className='imgAmet'></img>
          <p>21.02.2022</p>
          <h4>Title goes here can go on two lines</h4>


        </div>
        <div class="ametColumn" >
          <img src={productGlrl} className='imgAmet'></img>
          <p>21.02.2022</p>
          <h4>Title goes here can go on two lines</h4>


        </div>

      </div>
      <footer>


        <li className="footerColumn" >

          <ul><img src={Elegante} className='eleGanteFooter' /></ul>
          <ul className=''><img src={Twitter} className='twFaceInsta' /><img src={Facebook} className='twFaceInsta' /><img src={Insta} className='twFaceInsta' /></ul>
          <ul><img src={Paypl} className='payPl' /></ul>
          <ul ><p className='footerTxt'>© Eleganté 2022</p></ul>
          <ul ><p className='footerFTxt'>Site Designed & Developed by CDA</p></ul>
        </li>

        <ul class="footerColumnTxt" >
          <li>
            <h5>Shop</h5>
            <p>Hair</p>
            <p>Hair Care</p>
            <p>Skin & personal Care</p>
            <p>Makeup</p>
            <p>Fragrance</p>
            <p>Tools & accessories</p>
            <p>Tools & accessories</p>
          </li>
        </ul>

        <ul class="footerColumnTxt" >
          <li>
            <h5>Shop</h5>
            <p>Hair</p>
            <p>Hair Care</p>
            <p>Skin & personal Care</p>
            <p>Makeup</p>
            <p>Fragrance</p>
            <p>Tools & accessories</p>
            <p>Tools & accessories</p>
          </li>
        </ul>


        <ul class="footerColumnTxt" >
          <li>
            <h5>Shop</h5>
            <p>Hair</p>
            <p>Hair Care</p>
            <p>Skin & personal Care</p>
            <p>Makeup</p>
            <p>Fragrance</p>
            <p>Tools & accessories</p>
            <p>Tools & accessories</p>
          </li>
        </ul>

        <ul class="footerColumnTxt" >
          <li>
            <h5>Subscribe to our newsletter</h5>
            <input className="footerText" type="text" placeholder="Name" />
            <input className="footerText" type="text" placeholder="Email" />
            <input type="checkbox" className='inputCheck' />
            <label style={{ fontSize: "10px" }}> I agree to all marketing communications</label>
            <button className="buttonTxtFooter">SHOP NOW</button>

          </li>

        </ul>





      </footer>
      {/* <!--end of footer--> */}

    </div>

  );
}

export default App;
